﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace lecture3
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteToFile();
            ReadFromFile();
        }
        static void Task1()
        {
            int number1;
            int number2;
            int sum;
            Console.WriteLine("Enter 1st number : ");
            number1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter 2nd number : ");
            number2 = int.Parse(Console.ReadLine());
            sum = add(number1, number2);
            Console.WriteLine("Sum : " + sum);
            Console.Read();
        }
        static int add(int num1,int num2)
        {
            return num1 + num2;
        }
        static void ReadFromFile()
        {
            string path = "C:\\week01\\lecture3\\ProductFile";
            if(File.Exists(path))
            {
                StreamReader file_variable = new StreamReader(path);
                string record;
                while((record=file_variable.ReadLine())!=null)
                {
                    Console.WriteLine(record);
                }
                file_variable.Close();
            }
            else
            {
                Console.WriteLine("Not Exist!");
            }
            Console.Read();
        }
        static void WriteToFile()
        {
            string path = "C:\\week01\\lecture3\\ProductFile";
            StreamWriter file_variable = new StreamWriter(path, true);
            file_variable.WriteLine("Hello");
            file_variable.Flush();
            file_variable.Close();
        }

    }
}
