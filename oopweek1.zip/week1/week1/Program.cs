﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week1
{
    class Program
    {
        static void Main(string[] args)
        {
            LillyTask6();
        }
        static void PassTask()
        {
            string input;
            float marks;
            Console.Write("Enter your marks:");
            input = Console.ReadLine();
            marks = float.Parse(input);
            if (marks > 50)
            {
                Console.WriteLine("You are passed!");
            }
            else
            {
                Console.WriteLine("You are fail!");
            }
            Console.Read();
        }
        static void LoopTask2()
        {
            for(int x=0;x<5;x++)
            {
                Console.WriteLine("Welcome jack!");
            }
            Console.Read();
        }
        static void NegativeTask3()
        {
            string input;
            int number;
            int sum = 0;
            Console.Write("Enter any number:");
            input = Console.ReadLine();
            number = int.Parse(input);
            while(number!=-1)
            {
                sum = sum + number;
                Console.Write("Enter any number:");
                input = Console.ReadLine();
                number = int.Parse(input);
            }
            Console.Write("Sum : "+sum);
            Console.Read();
        }
        static void DoWhileTask4()
        {
            int number;
            int sum = 0;
            do
            {
                Console.Write("Enter any number:");
                number = int.Parse(Console.ReadLine());
                sum = sum + number;
            }
            while (number != -1);
            Console.Write("Sum : " + sum);
            Console.Read();
        }
        static void LargestTask5()
        {
            int[] number = new int[5];
            int largest = 0;
            for(int i=0;i<3;i++)
            {
                Console.Write("Enter any number:");
                number[i] = int.Parse(Console.ReadLine());
            }
            for (int i = 0; i < 3; i++)
            {
                if(number[i] > largest)
                {
                    largest = number[i];
                }
            }
            Console.WriteLine("The largest number is : " + largest);
            Console.Read();
        }
        static void LillyTask6()
        {
            int age;
            float Machine_price;
            float Toy_price;
            float money=0;
            int x = 1;
            Console.Write("Enter Lilly age : ");
            age = int.Parse(Console.ReadLine());
            Console.Write("Enter price of machine : ");
            Machine_price = float.Parse(Console.ReadLine());
            Console.Write("Enter price of toy : ");
            Toy_price = int.Parse(Console.ReadLine());
            for(int i=1;i<=age;i=i+1)
            {
                if (i % 2 == 0)
                {
                    money = (money + x*(10))-1;
                    x++;
                }
                else if(i%2==1)
                {
                    money = money + Toy_price;
                }
            }
            if(money>Machine_price)
            {
                Console.WriteLine("Yes! where" + (money - Machine_price) + " is remaining money");
            }
            else
            {
                Console.WriteLine("No! " + money + " is not enough!");
            }
            Console.Read();
        }
        
    }
}

