﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Login
{
    namespace SignIn
    {
        internal class Program
        {
            static void Main(string[] args)
            {
                string path = "C:\\week01\\Login\\UserFile.txt";
                const int size = 100;
                string[] Names = new string[size];
                string[] Passwords = new string[size];
                int userCount = 0;
                string name, password;
                string choice = "0";
                ReadData(path, Names, Passwords, ref userCount);
                while (choice != "3")
                {
                    choice = Menu();
                    if (choice == "1")
                    {
                        Console.Write("Enter username : ");
                        name = Console.ReadLine();
                        Console.Write("Enter password : ");
                        password = Console.ReadLine();
                        bool check = Signin(name, password, Names, Passwords, userCount);
                        if (check)
                        {
                            Console.WriteLine("Signed in succesfully");
                            Clear();
                        }
                        else
                        {
                            Console.WriteLine("Wrong Credentials!");
                            Clear();
                        }
                    }
                    else if (choice == "2")
                    {
                        Console.Write("Enter username : ");
                        name = Console.ReadLine();
                        Console.Write("Enter password : ");
                        password = Console.ReadLine();
                        bool check = Signup(name, password, Names, Passwords, ref userCount);
                        if (check)
                        {
                            WriteData(path, name, password);
                            Console.WriteLine("Signed up successfully....");
                            Clear();
                        }
                        else
                        {
                            Console.WriteLine("User already available!");
                            Clear();
                        }

                    }
                    else if (choice == "3")
                    {
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Invalid input!");
                        Clear();
                    }
                }
            }

            static void Clear()
            {
                Console.WriteLine("Press any key to continue......");
                Console.ReadKey();
                Console.Clear();
            }

            static string Menu()
            {
                string option;
                Console.WriteLine("=======================================");
                Console.WriteLine("1.\tSign in");
                Console.WriteLine("2.\tSign up");
                Console.WriteLine("3.\tExit");
                Console.WriteLine("_______________________________________");
                Console.WriteLine("Enter an option");
                option = Console.ReadLine();
                return option;
            }

            static bool Signin(string Name, string password, string[] Names, string[] Passwords, int count)
            {
                bool flag = false;
                for (int i = 0; i < count; i++)
                {
                    if (Name == Names[i] && password == Passwords[i])
                    {
                        flag = true;
                    }

                }
                return flag;
            }

            static bool Check(string Name, string password, string[] Names, string[] Passwords, int count)
            {
                bool flag = true;
                for (int i = 0; i < count; i++)
                {
                    if (Name == Names[i] && password == Passwords[i])
                    {
                        flag = false;
                    }
                }
                return flag;

            }

            static bool Signup(string Name, string password, string[] Names, string[] Passwords, ref int count)
            {
                bool flag = false;
                bool check = Check(Name, password, Names, Passwords, count);
                if (check)
                {
                    Names[count] = Name;
                    Passwords[count] = password;
                    count++;
                    flag = true;
                }
                return flag;

            }

            static string parseData(string record, int field)
            {
                int comma = 1;
                string str = "";
                for (int i = 0; i < record.Length; i++)
                {
                    if (record[i] == ',')
                    {
                        comma++;
                    }
                    else if (comma == field)
                    {
                        str += record[i];
                    }
                }
                return str;
            }
            static void WriteData(string path, string name, string password)
            {
                StreamWriter file = new StreamWriter(path, true);
                file.WriteLine(name + "," + password);
                file.Flush();
                file.Close();
            }
            static void ReadData(string path, string[] Names, string[] Passwords, ref int count)
            {
                if (File.Exists(path))
                {
                    StreamReader file = new StreamReader(path);
                    string record;
                    while ((record = file.ReadLine()) != null)
                    {
                        Names[count] = parseData(record, 1);
                        Passwords[count] = parseData(record, 2);
                        count++;
                    }
                    file.Close();
                }
            }
        }
    }
}