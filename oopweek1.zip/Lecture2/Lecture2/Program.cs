﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lecture2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Task8();
            Task10();
        }
        static void Task1()
        {
            Console.Write("Hello World!");
            Console.Write("Hello World!");
            Console.ReadKey();
        }
        static void Task2()
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine("Hello World!");
            Console.ReadKey();
        }
        static void Task3()
        {
            int variable = 3;
            Console.WriteLine("Value : ");
            Console.Write(variable);
            Console.ReadKey();
        }
        static void Task4()
        {
            string variable = "I am a String";
            Console.WriteLine("String : ");
            Console.Write(variable);
            Console.ReadKey();
        }
        static void Task5()
        {
            Char variable = 'A';
            Console.WriteLine("Character : ");
            Console.Write(variable);
            Console.ReadKey();
        }
        static void Task6()
        {
            float variable = 2.2F;
            Console.WriteLine("Decimal : ");
            Console.Write(variable);
            Console.ReadKey();
        }
        static void Task7()
        {
            string str;
            str = Console.ReadLine();
            Console.WriteLine("You have inputted : ");
            Console.WriteLine(str);
            Console.ReadKey();
        }
        static void Task8()
        {
            string str;
            str = Console.ReadLine();
            Console.WriteLine("You have inputted : ");
            int num = int.Parse(str);
            Console.WriteLine("The number is : ");
            Console.WriteLine(num);
            Console.ReadKey();
        }
        static void Task9()
        {
            string str;
            Console.WriteLine("Enter floating point number : ");
            str = Console.ReadLine();
            float num = float.Parse(str);
            Console.WriteLine("The floating value is : ");
            Console.WriteLine(num);
            Console.ReadKey();
        }
        static void Task10()
        {
            float length;
            float area;
            Console.WriteLine("Enter Length of one side : ");
            length = float.Parse(Console.ReadLine());
            area = length * length;
            Console.WriteLine("The area is : ");
            Console.WriteLine(area);
            Console.ReadKey();
        }
    }
}
